import Foundation

class Person {
    //Saludar
    //param: Nombre 
    //return: El nombre concatenado de otro mensaje
    func greet(name: String) -> String {
        return "\(name) mucho gusto"
    }
    //Caminar
    //param: Pasos
    //return: La cantidad de pasos dados
    func walk(steps: Int) -> String{
        return "Tu haz dado \(steps) pasos" 
    }
}
var randomPerson = Person()
print(randomPerson.greet(name: "Luis"))
print(randomPerson.walk(steps: 12345))

print("----------------------------------------")

struct Screen{
    //Defino el ancho y lo alto de la pantalla
    var width: Int
    var high: Int

    //Creo mi constructor para inicializar la estructura
    init(width: Int, high: Int){
        self.width = width
        self.high = high
    }
}

var myPhone = Screen(width: 73, high: 155)
print("El ancho de la pantalla es de \(myPhone.width) cm y el alto es de \(myPhone.high) cm ")

print("----------------------------------------")

extension Int{
    func hoursToSeconds()->Int{
        return (self * 3600) / (1) 
    }
}
print("4 horas a segundos son:",4.hoursToSeconds())

print("----------------------------------------")

extension String{
    func week()->String{
        switch self {
        case "Domingo":
            return "1"
        case "Lunes":
            return "2"
        case "Martes":
            return "3"
        case "Miércoles":
            return "4"
        case "Jueves":
            return "5"
        case "Viernes":
            return "6"
        case "Sábado":
            return "7"
        default:
            fatalError("Unsupported")
        }
    }
}
var day = "Viernes: "
print(day.week())

print("----------------------------------------")

//Defino la opcional
var number: Int?
//Le asigno un valor
number = 42
//Pregunto si number tiene algún valor
if number != nil {
    //Si es así, lo imprimo
    print(number!)
} else {
    //De lo contrario digo que no tiene
    print("No tiene valor")
}

print("----------------------------------------")
let days = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200]
var isInDays:Int?

print(isInDays==days["DF"])
